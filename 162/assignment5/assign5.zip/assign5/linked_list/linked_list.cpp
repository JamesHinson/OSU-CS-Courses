#include "linked_list.h"

int Linked_List::get_length() {
	// note: there is no set_length(unsigned int) (the reasoning should be intuitive)
	// Your code goes here:

	return -1;
}

void Linked_List::print(){
	// output a list of all integers contained within the list
	// Your code goes here:
	cout << "\n";
	return;
}

void Linked_List::clear(){
	// delete the entire list (remove all nodes and reset length to 0)
	// Your code goes here:

	return;
}

void Linked_List::push_front(int val){
	// insert a new value at the front of the list 
	// Your code goes here:

	return;
}

void Linked_List::push_back(int val){
	// insert a new value at the back of the list 
	// Your code goes here:

	return;
}

void Linked_List::insert(int val, int index){
	// insert a new value in the list at the specified index 
	// Your code goes here:

	return;
}

void Linked_List::pop_back(){
	// remove the node at the back of the list
	// Your code goes here:

	return;
}

void Linked_List::pop_front(){
	// remove the node at the front of the list
	// Your code goes here:

	return;
}

void Linked_List::remove(int index){
	// remove the node at index of the list
	// Your code goes here:

	return;
}

void Linked_List::sort_ascending(){
	// sort the nodes in ascending order. You must implement the recursive Merge Sort algorithm
	// Note: it's okay if sort_ascending() calls a recursive private function to perform the sorting.
	// Your code goes here:

	return;
}

void Linked_List::sort_descending(){
	// sort the nodes in descending order
	// Your code goes here:

	return;
}
